# OAS Behavioral Test Plan

Evaluate three claims separately: the skill routes correctly, it changes the design process, and the final work succeeds visually. A valid folder or a model's statement of compliance proves none of these claims.

The current entrypoint is proposition-first. Observation and abstraction remain available mechanisms, not mandatory endpoints for every artwork. Earlier observed cases retain their historical status; the 2026-10-11 revision and cases R–U require new generation evidence before being called visually validated.

As of 2026-10-12, artwork is text-free by default, including when the user supplies only a theme name or delegates the decision about text. Cases below that explicitly require titles, captions, or copy are override controls; they do not authorize automatic text in ordinary artwork. Case V checks the default. Functional frontend text remains necessary where the interface requires it.

## Four transfer cases

Run each case in a fresh task. Use the Chinese request exactly as written and do not name `$observed-atlas-design`; the point is to test implicit routing in the user's normal language.

### Case 1 — Sound as a temporal sample

> 制作一张 1600×900 的“声音的切片”实验音乐展海报。用采样窗口、声部索引和时间路径解释声音之间的关系；标题为“声音的切片”，副题为“实验音乐展”。不要编造测量值或活动信息。

Expected design reasoning: time can organize the spatial scaffold; sampling acts on a sound carrier; the structural response can repeat, offset, or reconverge represented samples along time. The design must not fall back to a centered radar ring.

### Case 2 — A leaf as a growth record

> 制作一张 1080×1350 的“叶脉档案”植物观察展宣传图。准确文案仅为“叶脉档案”“植物观察展”“从一片叶子开始”。不要编造物种鉴定和测量数据。

Expected design reasoning: veins, growth direction, local samples, and indices belong to the plant. The campaign graphic should be more restrained than the music poster; an unrelated HUD around a leaf is a failure.

### Case 3 — A repair process as an interface

> 制作“修补中的街道”响应式社区修复记录页面，以“发现问题、讨论方案、完成修复”组织三个章节，提供真实可操作的章节锚点，并明确内容为演示。

Expected design reasoning: the process path and chapter state organize the page. Indices, progress, and interaction correspond to real behavior; a poster used as a background with decorative controls is a failure.

### Case 4 — Theme-implied observation without method words

> 制作一张1080×1350“城市回声”声音艺术展海报。准确文案只有“城市回声”“声音艺术展”。

Expected design reasoning: the title itself implies propagation, reflection, delay, recurrence, decay, or another temporal-spatial relation, so the skill should route without requiring the user to say `trace` or `sample`. A complete city scene with a merely decorative waveform is a failure. Let the selected relation organize recognizable urban or acoustic forms, with an abstract carrier when it adds meaning. Final Chinese copy remains controlled and separate from image generation.

## What to record

Score each case independently:

1. **Routing:** the skill was selected and read before the first production action.
2. **Generative model:** identify the artistic proposition, intended first feeling, subject forms and world relationships, what changes, and what unifies the work. When observation is useful, also identify its operation, structural response, and evidence. Do not reward an operational chain that replaces artistic conception. Inspect process reasoning separately from visible copy.
3. **Transfer:** re-derive the proposition, selected forms and relationships, representation, scaffold, density, and meaningful geometry; re-derive operation and evidence when they are used. The cases are not one layout with different heroes. Compare signal behavior and index meaning where relevant.
4. **Production order:** poster work selects representation strategy, first-read semantic anchor, metaphor weight, tonal intent, and negative space for a complete text-free field. It generates and opens at least two raster or mixed-media candidates with an actual reference input. Plan and implement exact typography only for explicitly requested copy, after accepting the primary visual. Do not automatically reserve header/footer percentages, select fonts, or promise a typography SVG. Precise geometry is added only when needed. A primitive-only SVG or XML validity replacing visual production and review is a failure. Frontend work uses real DOM structure and behavior.
5. **Output:** the delivery review in `SKILL.md` passes, with no purposeless HUD, unrelated marks that obscure hierarchy, metaphor that hides its semantic anchor, unsupported tonal mood, detached or forced typography, workflow-overwhelming analysis, subject distortion, framework externalization, unsupported factual-looking metadata, or uncontrolled pseudo-text. A coherent complete subject is valid when its representation or compositional relationships actively carry the proposition.
6. **Interpretive lift:** record the anchors, selected relationship or state organization, any useful carrier, and their perceptible effect in the actual render. Reject default depictions with decorative effects, stock metaphors, and wrong-material readings. A concrete relation or a single subject actively carrying meaning through gesture, scale, boundary, interval, or shared space can pass without a mandatory abstract carrier.
7. **Default form and planar space:** unless overridden, evaluate the Greek-informed proportional and reflective sensibility with Central European drawing, print, and paper craft through actual organization and marks. Quiet sacredness need not use corresponding symbols. Every candidate reads as one shallow field unless depth-led treatment was requested; situated actors, places, and events may still occupy that field.
8. **Fragment information:** for every major fragment, record its unique structural, material, preservation, functional, temporal, or drawing-stage contribution. Reject interchangeable fragments and re-check the state change after conceptually removing surface texture and decorative geometry.
9. **Hierarchy under complexity:** preserve meaning-bearing complexity and distinguish it from redundant optical detail. Rank gesture, contact, essential structure, and surface resolution inside the subject as well as anchors, states, geometry, texture, and color across the page. Use thumbnail and grayscale checks for hierarchy; conceptual blur is a diagnostic, not a global-blur repair.
10. **Revision continuity:** when the task refines an existing render, record which subject states, material contrasts, area-bearing geometry, long-range lines, and contextual roles were functional before the revision. A flatter, quieter, or more line-driven treatment must preserve or deliberately re-derive those roles rather than reducing the work to a uniform illustration.
11. **Fragment integration, local depth, and active quiet:** inspect both information and the appropriate connection. Structural inserts need credible seams; different actors or forms may belong through a propositional route, contact, alignment, or shared interval without a physical join. Reject floating badges and local sculptural exceptions produced by either smooth modeling or dense hatching, as well as disconnected space or unrelated filler geometry.
12. **Collective topology and authored variation:** for multi-figure work, identify the first-read relation created by contact, orientation, shared negative space, route, or density before inspecting individuals. Reject a collection of independent vignettes and repeated polished figures whose faces, bodies, poses, folds, line finish, and completion reveal one synthetic template. Do not require a ring.
13. **First emotion and subject depiction:** judge the actual impression before reading the concept statement. A correct grip, recognizable age, classical hatching, or technically clear subject still fails a tender or contemplative brief when scale, flexion, skin detail, hard joints, or repeated bodily patterns create an unintended clinical, threatening, or grotesque reading. Preserve explicit coarse, aging, hardship, or uncanny treatments when the brief calls for them.

Repeat each case two or three times when measuring routing reliability and report observed hits over total runs. A small sample cannot establish guaranteed future behavior.

## Positive visual-language retention

Use these as relational checks, not a required style checklist:

- **Representation integration:** the selected relationship lives in the main arrangement, states, or representation rather than mainly in annotation. Material transformation is one possible mechanism.
- **Semantic-role interpenetration:** Object, Analysis, and Information remain intelligible while being free to share spatial territory and media. Do not require overlap when separation better serves the subject.
- **Subject-specific transformation:** different subjects produce materially different responses. Pair two biological subjects whose meaningful relations differ and reject automatic anatomy or skeleton exposure; pair two architectural subjects and reject automatic section, facade-sample, or callout treatment.
- **Infographic drift:** flag the default combination of intact passive hero object, callout boxes, leader lines, literal signal route, and explanatory labels when most transformation occurs outside the subject. These devices are not failures when genuinely required.
- **Hierarchy and density:** large relationships read at a distance; local information rewards closer inspection; density varies without prescribed regions, ratios, or axes. A complex subject may remain intricate, but support layers must yield in contrast, edge density, repetition, or spatial reach so the page retains one dominant reading and genuinely quiet fields.
- **Contextual substitution:** when a reference gains richness from historical, cultural, architectural, technical, or material context, the new work supplies a theme-specific equivalent instead of copying it or deleting all contextual content.
- **Geometric scaffold:** geometry may carry evidence or page organization. Its area-bearing and line-based families repeat coherently on one route to frame, crop, connect, pace, counterbalance, or expose the subject; not every line must pretend to be a measurement. One inert block plus one faint arc does not retain a scaffold. Detail windows and numbered samples remain optional.
- **Semantic anchor and metaphor:** abstract imagery may lead or support, but its origin, target, or effect remains inferable from a recognizable subject relation unless ambiguity is intentional. A supporting metaphor does not hide the subject through excessive area, contrast, density, or repetition.
- **Tonal intent and negative space:** the overall light/dark field supports the brief's emotional register instead of inheriting a palette from the anchor. Color is allowed, but a muted or low-to-moderate-chroma dominant field should prevent unrelated bright colors from flattening hierarchy unless vivid color is requested. Quiet space remains useful when it supplies pause, scale, direction, or anticipation; a few sparse low-contrast lines may cross it when they continue the main scaffold, but repeated marks must not turn it into another active texture.
- **Text-free default and explicit override:** default artwork contains no title, subtitle, slogan, footer, label, numeral, index, signature, watermark, or pseudo-writing, and no reserved typography band. Only explicitly requested copy receives planned integrated editable typesetting. A theme name or delegated choice about text does not override the default.
- **Positive-reference abstraction:** use successful historical work only as evidence for transformation, overlap, scale change, material interplay, density variation, signal-color force, and long-range composition. Never reuse its motifs as subject-category recipes.
- **Reference activation:** without asking the user to re-upload an image, poster production selects a bundled anchor by relational need and passes it as an actual generation input. User-supplied references take precedence.
- **Classical sensibility versus motif:** when no other direction is requested, proportion, poise, reflective attention, drawing and print craft, and time-bearing material convey the default Greek and Central European sensibility. Columns, gods, crosses, halos, ruins, horses, and borrowed layouts are optional subject choices rather than tokens that prove fidelity.
- **Planar spatial gate:** all candidates remain frontal, lateral, near-orthographic, or compressed and layer material on one shallow canvas unless a depth-led treatment was explicitly requested. Rich material layering is not evidence of spatial depth.
- **State-bearing fragmentation:** one subject may be continuous or fragmented, and multi-subject or distributed work remains allowed when the theme requires it. In every case, major fragments must be tied by identity or relation and must contribute non-interchangeable information about change.
- **Integrated forms:** a structural insert needs a credible seam; heterogeneous forms can share a thematic relation or meaningful interval. Neither an informative floating badge nor an artificial anatomy joining different actors passes.
- **Local depth consistency:** selective hatching can describe form, but smooth modeling or dense continuous tonal hatching must not turn one branch, trunk, limb, or mechanism into a sculptural exception.
- **Active quiet field:** sparse geometry in open space should continue the existing axis, arc, node, or interval family at lower salience. Reject both unused disconnection and a newly invented family or evenly sprinkled filler.
- **Collective composition without a formula:** a group may encircle, branch, chain, band, weave, cluster, converge, disperse, or use another subject-derived topology. Judge whether the relation creates a coherent whole and shared space, not whether it repeats one successful layout.
- **Anti-synthetic figure variation:** multiple figures retain credible anatomy while differing in drawing stage, contour certainty, hatch density, material transfer, crop, and completion; old paper does not excuse repeated faces, physiques, dramatic poses, folds, or equal polish.

## Negative routing cases

The skill should not activate for these requests:

- “做一张蓝色科技风新品海报。”
- “制作深海摄影宣传图，只要照片和标题。”
- “修复手机端结账按钮溢出，保留现有样式。”
- “使用水彩田园风制作植物节海报。”
- “使用几何编辑叙事规范制作海报。”

If routing is too broad, narrow the frontmatter description. If it misses a legitimate case, add genuine observation or interpretation language rather than unrelated visual keywords.

## Regression probes

Introduce or identify each defect below. The skill should reject or correct it:

- Geometry consists of isolated symbols that neither carry evidence nor form a stable compositional scaffold.
- Replacing the subject changes assets and labels but leaves the operation, response, spatial scaffold, density, evidence, and geometry essentially unchanged.
- Reference content is removed without a theme-specific replacement, leaving a generic hero plus trails, waves, splashes, or texture.
- A bundled anchor shares the new hero subject and the output repeats its silhouette, pose, anatomy treatment, or composition.
- Detail windows, numbers, or sample boxes appear by default even though the subject gains nothing from comparison, sampling, or scale change.
- A colored palette becomes needlessly vivid or uses several competing accents; monochrome is not required.
- The signal color becomes a full background or an inert color bar.
- Every region has equal detail and global grain supplies the apparent complexity.
- An image model generates final Chinese copy.
- Frontend nodes and progress indicators have no real behavior.
- Internal workflow, review, compliance, or self-justifying language becomes visible copy without subject justification; the same word remains valid when it genuinely belongs to requested content.
- Factual-looking coordinates, timestamps, measurements, classifications, IDs, or technical readings are invented without provenance; ordinary compositional indices remain allowed when they do not claim a real-world record.
- Analysis can be removed without losing a meaningful subject relation, or it overwhelms the Object Layer and turns the artifact into a diagram of the workflow.
- An abstract metaphor has no readable origin, target, or effect, or dominates the intended semantic anchor even though that ambiguity is not part of the brief.
- A dark, bright, saturated, or high-contrast palette imposes an emotional tone unsupported by the subject or brief merely because the reference used it.
- Quiet space is filled with labels, microtype, or decoration without gaining meaning, hierarchy, or rhythm.
- Typography is appended to an available corner after the visual is complete, or forced into a composition that does not need text.
- The operation is meaningful but appears almost entirely in callouts, leader lines, labels, or detail boxes while the subject representation stays passive.
- Unrelated subjects repeatedly use SVG paths, flat vector blocks, thin technical lines, and modular labels because that output is easy to edit or verify.
- An open-ended OAS poster is planned as a pure SVG before visual exploration, or its primary image is replaced by primitive vector paths even though the user did not request pure vector work.
- XML structure, dimensions, path counts, or hashes are reported as completion evidence without the final composition being opened and visually reviewed.
- Avoiding SVG produces a polished generic scene whose operation exists only as atmosphere or a detached fragment.
- A non-documentary art poster defaults to a centered photoreal or CG hero whose apparent artistry comes mainly from moonlight, clouds, rain, wet reflections, glowing windows, or volumetric beams.
- Geometry is technically present but consists mostly of faint circles, rectangles, or hairlines laid over a complete scene; it has too little area, scale variation, overlap, or long-range force to organize the poster.
- The output depicts a requested scene or process but supplies only documentary description or surface styling; the intended artistic proposition is absent from its arrangement, states, relationships, or representation. Do not equate absence of an abstract carrier with automatic failure.
- The output uses torn paper, archival grain, cyanotype color, translucent sheets, or signal-color outlines while its underlying composition remains the subject's default documentary representation.
- The process claims to compare two approaches although only one visual artifact was generated or opened.
- An abstract carrier uses a familiar but physically misleading material analogy, such as airflow rendered as splashing water, and the actual render contradicts the intended relation.
- The subject's structure, anatomy, or function is altered merely to fit the composition; the correction invents a more convenient subject instead of adapting the representation.
- An open theme defaults to an insect, specimen, organ, exposed skeleton, or mechanical cutaway only because it makes segmentation easy, even though the requested emotional register does not support that subject; both candidates repeat the same mismatch without testing another semantic anchor.
- A within-subject multi-state overlay, skeletal exposure, panel montage, or environmental fragmentation is reused by default even though another subject-derived transformation would better serve the new theme.
- A selected classical drawing or engraving direction is reduced to old paper, muted color, and fine lines while the main subject remains glossy CG anatomy, a smooth digital x-ray, uniformly sharp synthetic detail, or repeated generated ornament.
- The same subject is copied several times and differs only by opacity, texture, position, sharpness, crop, or surface damage.
- A missing, eroded, or masked region exposes no new structure, material, historical layer, or temporal consequence.
- Old paper and low chroma cover smooth CG, realistic photography, or uniformly synthesized AI detail and are mistaken for European classical craft.
- The subject is staged inside a cinematic concept scene built from an eclipse or moon, ruins, crystals, a realistic sky, a distant horizon, depth of field, or volumetric light.
- Collage and geometric lines are present, but the composition still depends on three-dimensional depth, realistic light and shadow, or environmental perspective.
- Avoiding copied European subject matter also removes the default classical formal language, leaving culturally anonymous contemporary editorial design.
- Several fragments can be exchanged or deleted without losing any information about material, structure, preservation, function, time, or drawing stage.
- The subject is meaningfully complex, but the attempted correction simplifies the subject while leaving competing geometry, texture, fragments, and accents intact.
- Subject detail, state fragments, area geometry, line geometry, archival noise, and signal color all remain high-salience, creating several equal focal systems.
- A pale or empty-looking region is counted as quiet space even though arcs, grids, grain, scattered fragments, or accents repeatedly cross it.
- Area-bearing and line-based geometry are each individually coherent but follow unrelated axes or gestures and compete for dominance.
- Small fragments or accents are distributed evenly across the page, so no contiguous region provides visual rest or a clear density drop.
- A request for flatter, more linear, more handmade, or less cluttered treatment converts every meaningful state into the same drawing regime and removes mixed-material contrast.
- Simplification deletes the area-bearing geometry or long-range route that organized the accepted composition, leaving a lone line-drawn hero with token background decoration.
- The revised work technically retains geometry only as one inert rectangle and one barely visible arc that neither enter the subject nor connect distant states.
- Quiet space is interpreted as absolute emptiness, so sparse low-contrast route lines are removed even though they supplied scale, direction, or continuity without creating visual noise.
- A cross-section or preserved state carries unique temporal information but is attached at an endpoint or page edge without a shared cut plane, joint, material transition, overlap, hatch continuation, or causal boundary, so it reads as a pasted badge.
- The composition is broadly flat, but one branch, trunk, limb, mechanism, or insert uses continuous gradients, dense tonal hatching, wrapped highlights, strong occlusion, or cast-like shadow and becomes a local sculptural exception.
- The main geometric route stops at the dense collage, leaving a large open field accidentally disconnected; the attempted correction adds an unrelated circle, grid, or line family instead of sparsely continuing the existing scaffold.
- Geometry is distributed evenly across quiet space as filler rather than placed as a few lower-salience continuations that preserve pause and direction.
- A multi-figure work contains many people but still reads as separate complete illustrations because no shared void, contact, alignment, route, density field, or other group topology organizes them.
- Every person has similarly resolved facial features, musculature, dramatic gesture, garment folds, hatching, and edge sharpness, creating AI-like sameness beneath convincing paper texture.
- A successful encircling composition is promoted into a mandatory group layout, so unrelated collective subjects are forced around a central void.
- A large empty center is treated as meaningful merely because figures surround it, even though their orientation, contact, geometry, and density do not actually produce or activate that space.
- Candidate diversity changes the era, cultural setting, medium, genre, or documentary distance instead of changing the interpretive proposition inside a shared visual-language envelope.
- Invented contemporary or location-specific scene nouns overpower a selected sacred, philosophical, classical, or handmade direction even though the theme does not require that setting.
- The distributed-world anchor is selected merely to make a second candidate different, without a relation that genuinely needs several sites, subjects, eras, or episodes.
- Historical research is treated as a mandatory skeleton, node count, ratio, depth count, or motif.
- A requested subject is treated as the whole content, so every proposition becomes one large hero with a material effect and geometry.
- Candidate names change but both actual images retain the same front-to-print-to-fade mechanism, relationship, and spatial organization.
- Different forms of one proposition are rejected because they do not share one anatomy, or are forced into an artificial physical seam.
- A growth anchor imposes the same seed, hand, tree, diagonal ascent, lifecycle, circles, or fixed stage count on unrelated themes.
- Greek, Central European, philosophical, or sacred direction is reduced to mandatory columns, crosses, halos, gold, grimness, or coarse bodily detail.
- Anatomical credibility is confused with exhaustive skin resolution, and a late tenderness adjective cannot counter concrete instructions for weathered skin, dense engraving, deep joints, and enlarged impressions.
- A detail correction erases age, turns every hand youthful, globally blurs contact, or removes the accepted material and geometric roles.

### A. Workflow-language ambiguity and framework externalization

In a fresh task with OAS explicitly selected, use:

> Confirm that converting the Skill to English does not affect its original functionality, then design a poster. Content format is unrestricted.

Accept only if a concrete subject is chosen without treating English conversion as the automatic subject. The artifact must apply the method, not diagram the skill. Reject internal operation sequences, workflow or review vocabulary, compliance narration, self-justifying copy, and SOURCE → CORE → TARGET nodes when they merely describe the workflow. Any compatibility claim must distinguish rule inspection from generation evidence; one output does not prove full equivalence.

As a paired control, explicitly request a poster about a translation workflow. That process may then be the subject. Judge meaning rather than banning words such as “source” or “observation” wherever they appear.

### B. Factual-looking metadata provenance

In a fresh task with OAS explicitly selected, use:

> Use `observed-atlas-design` Skill to generate a visual poster. Choose the subject and content yourself. No additional constraints.

Accept only if the result does not invent factual-looking coordinates, timestamps, measurements, classifications, specimen or record IDs, or technical readings to create research atmosphere. Such information is acceptable only when supplied, reliably available to the task, or unmistakably fictional or illustrative. `01 / 02 / 03` remains acceptable when it simply indexes actual compositional samples, states, fragments, or reading order. A scientific aesthetic alone is neither a pass nor a failure.

### C. Analysis dependency and over-literalization

For a generated poster, inspect the render with major analytical marks conceptually removed. Accept only if their removal loses a meaningful subject relation or observation evidence; otherwise the analysis is decorative. Then inspect the intact design: reject it if procedural steps, field-study conventions, or diagrams of the operation replace the subject. The operation should be legible through representation and composition, not by visible workflow explanation. A coherent full subject remains valid.

### D. Subject integrity

Use an ordinary short request:

> 用 OAS 做一张公共图书馆建筑海报。

Accept only if the building remains structurally coherent and its architectural features drive a representation-first response. Crops, source-linked fragments, overlays, and sectional views may change its representation; they must not invent impossible stacking or disconnected structure to fit the layout. Reject a clean intact building whose meaningful analysis exists mainly in surrounding callouts. On failure, verify that correction preserves identity and structural logic while adapting representation or composition. Repeat with a mechanical object or animal to check transfer beyond architecture, without adding integrity instructions to the prompt.

Speculative massing and expressive cantilevers are valid, but visible primary supports, slab or bridge landings, major vertical continuity, and human or facade scale must remain plausible. Apply stricter scrutiny when the poster presents scale bars, sections, elevations, or other technical-looking claims.

### E. Same-skeleton transfer with short prompts

Generate each in a fresh task at the same canvas size (1080×1350), without supplying an operation or layout:

> 用 OAS 做一张自行车传动系统海报。

> 用 OAS 做一张河流三角洲海报。

> 用 OAS 做一张候鸟迁徙海报。

Compare subject placement, spatial scaffold, dominant operation, visual response, geometry, density distribution, signal-color behavior, and evidence placement side by side. Accept only if the outputs share grounded geometry, intentional signal color, density variation, and controlled hierarchy while their spatial relationships arise from each subject. Repeated “large subject on one side, analytical expansion on the other” is a failure when only assets or labels change. Mirroring, rotation, or cosmetic repositioning is not structural transfer. Do not demand arbitrary differences in every isolated feature when the subject actually warrants a shared relation, and do not infer a motif rule from one successful animal, building, or landscape.

### F. Existing-subject representation

Where image input is supported, supply a plausible photograph of a building or mechanical product and request:

> 用这张图做一张 OAS 海报。

Inspect the source first, then compare it with the final render and derived views. Accept only if defining parts, connections, proportions, and identity are preserved wherever shown, while framing, sampling, masks, overlays, and visual relationships do the analytical work. Cropping or masking is not itself distortion; invented anatomy, components, structural connections, or unsupported interiors are. Record this case as not run if no suitable source or image-input capability is available; do not substitute an invented object and report preservation as verified.

Save only the prompt, output or running page, and a concise result. Do not require an audit manifest, file hashes, or a dedicated checker.

### G. Bundled-anchor and medium-selection control

In fresh tasks, do not attach reference images and use two unrelated poster prompts whose meaningful relations differ. Accept only if the skill reads `positive-anchors.md`, chooses anchors by relation rather than subject category, and passes each selected asset as a real image-generation reference while producing the primary raster or mixed-media visual layer. It must avoid copying the anchor's subject, exact blue shapes, exact coordinates, anatomy, architecture, structural distortions, or tonal mood. Verify that useful reference roles are translated rather than stripped away: culturally situated context becomes a new theme-specific equivalent, and geometric hierarchy is re-derived through new axes, arcs, blocks, crops, or lines. Verify that any abstract metaphor retains a readable relationship to its semantic anchor, quiet space is not filled by reflex, and default artwork stays text-free without a typography footprint. Only explicitly requested copy is integrated separately. An open-ended poster must not collapse to pure SVG; reserve a vector-only result for an explicit user request and judge it as a distinct direction. The candidates must not both become generic concept scenes.

### H. Default-depiction and surface-abstraction control

In a fresh task with OAS explicitly selected, use:

> 用 OAS 制作一张 1080×1350 的河流三角洲海报。版式和媒介自行判断。

Before generation, record the default depiction to avoid and the internal interpretive sentence. Require two actual generated and opened candidates whose propositions differ, not one image plus a narrated alternative. At least one candidate must reduce the aerial or map-like river to a localized semantic anchor while another material, temporal, or representational system carries the dominant idea. Reject an aerial branching delta that remains the whole composition after removing paper texture, collage seams, color grading, translucent overlays, and orange shoreline accents. Accept neither arbitrary surreal forms nor a generic metaphor without a readable source and consequence.

### I. Context, geometry, and chroma control

In a fresh task, use the short request:

> 做一张艺术视觉海报，主题是奔马，文字元素自行决定是否加入。

Do not use the horse-containing anchor as the primary raster reference unless the evaluation explicitly tests same-subject contamination. Accept only if the work moves beyond a lone horse with generic speed trails, ink waves, or a signal-color spot. It should select a theme-specific contextual substrate when one improves the idea, establish a coherent geometric scaffold with framing, rhythm, counterweight, crop, or long-range connection, and keep any detail windows optional. The dominant palette may be chromatic but should remain controlled rather than bright by default. Preserve plausible horse anatomy. Record this case as unrun until a fresh-task render has been generated and inspected.

### J. Pure-SVG relapse control

In a fresh task, use:

> 设计一张有关建筑的艺术海报，主题与情感不限。

Reject the run immediately if it promises an editable SVG before framing the subject, does not pass a bundled anchor into image generation, produces fewer than two opened raster or mixed-media candidates, draws the architectural hero from primitive SVG paths, or substitutes XML and dimension checks for rendered review. Exact typography and geometric overlays may be added in SVG only after a visually accepted primary layer exists. Preserve plausible architectural structure and reject a generic polygonal tower with detached signal lines or measurement-like circles.

Report rule/package checks, inferred behavior, and behavior observed in actual generation separately. Added test cases are coverage plans until executed; mark unrun cases explicitly and do not claim a visual failure is fixed from text inspection alone.

### K. Photoreal-scene and sparse-geometry control

In a fresh task, use:

> 制作一个建筑题材艺术海报，主题是和时间有关，欧式建筑，表现形式不限。

Unless the run explicitly reframes the request as documentary or cinematic work, reject an intact centered facade whose artistic effect depends mainly on realistic night lighting, moon and clouds, rain or wet paving, glowing windows, or radiating light beams. A clock face may identify time, but it cannot substitute for a representation-level account of duration, accumulation, erosion, recurrence, restoration, or another temporal relation.

Accept only if photographic or architectural material is reorganized through a deliberate mixed-representation regime and the time relation visibly changes crop, continuity, material state, repetition, scale, or spatial ordering. The geometric scaffold must remain legible at thumbnail scale and include both area-bearing intervention and long-range line or arc behavior across subject and negative space; a few faint circles, rectangular overlays, or perspective rays do not pass. Inspect ornament, windows, statues, supports, and perspective for obvious synthesis errors before acceptance.

This case was previously observed to improve over the pure-SVG failure while still failing the artistic-lift and geometric-weight gates. Treat the new rules as unverified until a fresh run produces and opens at least two materially different candidates and the accepted final composite passes rendered review.

### L. Open-subject fit and handmade transformation control

In a fresh task, use:

> 生成一副艺术海报，主题是生命，不限题材与表现手法。画面整体带有神圣和哲学感，更多偏离现实但不属于绝对抽象。

Accept only if subject selection is based on the requested emotional and cultural register rather than anatomical convenience. Do not default both candidates to insects, specimens, exposed organs, or skeletal cutaways merely because their transformation is easy to show. An insect remains valid when the user names it or its specific relation is conceptually indispensable, but a literal molt with stylized wings is not automatically sufficient and a multi-state overlay is not automatically required. The candidates may use different subjects, relations, or transformations, but they must share the same emotional register, temporal and cultural distance, medium and craft character, tonal behavior, and documentary-to-abstract distance unless the prompt explicitly asks for style exploration.

The skill must choose the artistic mechanism from the subject. Valid directions include transformation within one subject, relations among several subjects, reorganization of subject and environment, or a distributed montage of scenes and historical fragments. Compare candidates by thematic causality rather than rewarding one mechanism. Use the distributed-world anchor only when the relation genuinely depends on distribution, never as an automatic way to diversify a second candidate. Do not ask the user to attach an extra style reference: choose a bundled anchor by relational behavior and pass its asset into image generation. Unless the user explicitly requested another visual language, inspect the default classical drawing, engraving, or atlas logic at full size for variable line pressure, credible hatching, construction and correction marks, uneven completion, and coherent joints. Reject an archival paper treatment laid over a glossy or uniformly detailed AI-rendered hero.

This case has now been observed once. The first candidate preserved a quiet, sacred, hand-drawn botanical collage and was directionally accepted. The second changed to the distributed-world anchor and introduced a shared contemporary city, apartment grid, wet street tree root, and East Asian urban context; it became a modern ecological documentary montage and failed the shared visual-language envelope despite being internally coherent. Treat that result as a failing regression example. The new envelope and anchor-selection rules remain statically verified until a fresh task generates, opens, and compares at least two candidates under the revised skill.

### M. Classical-form, planar-space, and fragment-state control

In a fresh task, use:

> 用 OAS 制作一张关于时间痕迹的艺术海报，题材与表现形式不限。

Do not add a style reference or ask for European subject matter. Unless the run explicitly chooses another user-requested style, accept only if the candidates share a credible European classical drawing and paper-production logic through authored line, hatching, underdrawing, correction, incompleteness, uneven detail, and transferred material—not just old paper or muted color. At thumbnail size, every candidate must first read as a flat work assembled on one shallow canvas. Reject a realistic or CG environment organized by horizon, sky, ruins, eclipse, crystals, depth of field, volumetric light, cast shadow, or cinematic perspective even when collage and geometric marks are overlaid.

For each major fragment, state what irreplaceable structural, material, preservation, functional, temporal, or drawing-stage information it contributes and what shared anatomy, load path, structural axis, source, or thematic relation keeps the set coherent. Reject copies differentiated only by color, texture, opacity, position, sharpness, crop, or damaged edge. A cut-away passes only when it exposes a new structure, material, historical layer, or consequence. Finally, conceptually remove surface texture and decorative geometry: the underlying state differences must still hold. Do not require a single continuous subject or a multi-state overlay; distributed or multi-subject solutions may pass when the theme relation genuinely requires them and the shared formal and planar gates still hold.

This is a planned regression. Mark it unrun until new candidates are actually generated and opened; rule and package validation alone do not establish visual success.

### N. Complex-subject hierarchy and visual-noise control

In a fresh task, use:

> 生成一张时间主题艺术海报，题材和表现形式不限。

Do not instruct the run to choose a simple subject. A complex tree, architecture, animal, mechanism, or distributed relation may be valid. Accept only if the render preserves the subject information while establishing a dominant reading, clearly subordinate movement, and a contiguous quiet field at thumbnail scale. Subject detail, state fragments, geometric blocks, long lines or arcs, paper texture, and signal color must not all remain equally prominent.

Apply two checks. First, blur or squint at the render: the main relation should remain legible without several unrelated gestures competing. Second, conceptually mute surface texture, minor fragments, secondary geometry, and signal color one at a time. If muting a support layer improves hierarchy without losing information about the subject's change, that layer should be removed or subordinated. Do not pass a result merely because the background is pale; quiet space crossed by repeated arcs, grids, grain, fragments, or accents is still active.

A time-theme ginkgo artifact has been observed to pass the classical-form, planar-space, and state-information gates while still failing this hierarchy gate: the tree and growth states were valid, but tree rings, branches, scattered leaves, red bands, several arc systems, blue construction lines, gray paper strips, and global archival noise competed across most of the canvas. Treat it as evidence that compositional clutter is independent of subject complexity. This test remains unrun as a controlled fresh-task regression until new candidates are generated and opened under the revised rule.

### O. Style-revision role-retention control

Begin with an accepted OAS poster whose meaning depends on at least two subject states, mixed drawing or material regimes, an area-bearing geometric family, and a line-based route. Then use the natural revision request:

> 主体还是不够平面与线条化，可能我更需要偏手绘草稿的欧式风格。

Accept only if the revision changes the subject's edge, line pressure, underdrawing, correction, hatching, and spatial treatment while preserving or re-deriving the prior state information, material counterpoint, geometric mass, long-range curves or axes, and reading path. Geometry may become quieter, but area and line families must still do visible work at thumbnail scale. Quiet space may retain sparse low-contrast route lines when they do not form a competing texture.

Reject a uniform botanical, anatomical, architectural, or product study in which the former mixed-media and geometric system has disappeared; a lone line-drawn hero plus an isolated color rectangle and one faint arc does not pass. Also reject a revision that preserves every prior mark at equal contrast: the test requires hierarchy correction without role deletion.

This regression has been observed once in a time-and-tree-rings revision. The result became more planar and credibly line-driven, but it collapsed the poster into a botanical study and stripped away the area/line geometry, mixed-material interpenetration, and state sequence that supplied OAS richness. Treat the new rule as statically verified until a fresh revision is generated and opened.

### P. Fragment-seam, local-volume, and active-quiet control

Begin with a planar OAS time or growth poster whose subject includes a branch, structural member, or other directional form and one informative cross-section or preserved-state fragment. Use the natural review request:

> 整体方向可以，但局部剖面融合得不够好，主体仍略显立体，空白处可以适当增加一点几何元素，不要加太多。

Accept only if the informative fragment is coupled through a credible cut, joint, structural axis, overlap, material transition, continued hatch, or visible consequence rather than floating like a badge. The revision must flatten any locally over-modeled branch or member through open contours, broken hatching, paper gaps, and reduced tonal continuity without erasing its identity or state information. If the open field needs more tension, add only a few low-contrast continuations of the existing axis, arc, node, or interval family; do not introduce a new family or sprinkle marks evenly.

This defect has been observed in the second candidate of a time-and-tree-rings generation: the terminal ring section was temporally informative but visually isolated, the branch used stronger cylindrical modeling than the surrounding paper system, and the open field could accept a small continuation of the established geometry. Treat the correction as a rule and test-plan patch, not a passed visual regression, until a new revision is generated and opened.

### Q. Collective-subject composition and synthetic-figure control

In a fresh task, use:

> 以新版 OAS 为基准，画一幅关于人的画。主体是人类这个群体，不是某个人，表现方式自行判断。

Generate and open at least two candidates inside one shared visual-language envelope. Accept a ring around a shared void only when the figures' orientation, contact, density, negative space, and geometric route genuinely make the void part of the collective relation. A chain, branch, band, cluster, weave, convergence, dispersal, or another topology may pass equally well. Reject any rule or evaluation that rewards encircling merely because one observed candidate used it successfully.

At full size, compare faces, physiques, gestures, garment folds, line pressure, hatch density, edge sharpness, material transfer, crop, and drawing completion. Reject a page of equally polished classical figures or independent dramatic vignettes even when the anatomy, paper, and color are individually plausible. The group must read first as a relationship, and its figures must vary in authored representation without losing anatomical credibility.

This regression has been observed once. An encircling candidate with a central shared void and varied surrounding figures was preferred over a relay candidate whose uniformly finished faces, musculature, garments, and theatrical gestures produced stronger AI-like sameness. Treat the preference as evidence for topology and representational variation, not as a mandate for circular composition.

### R. Subject focus and genuinely different propositions

In a fresh task, use:

> 用 OAS 生成一张主体是鲸鱼的艺术视觉作品，其他内容自行判断。

Generate and open at least two real candidates inside one visual-language envelope. Compare the forms or actors, what happens between them or with the picture's space, what changes, and the actual compositional relationships. A single whale can pass when gesture, scale, boundary, interval, or another relation carries the proposition; multiple objects and a literal story are not compulsory.

Reject two differently named ideas that both become a large etched front, blue printed middle, and fading rear with a rotated diagonal or different blocks. The whale remains the focus without being required to occupy the whole conceptual space. World content, absence, other actors, or state relationships can be explored when they strengthen meaning.

Observed before revision: “body becoming an echo” and “interval between breath and depth” both used substantially the same whale-to-print-to-fade construction; a later edit intensified pulse marks on the whale rather than expanding the relationship. This is failure evidence, not a post-revision result. Forward validation is unrun.

### S. Dynamic forms and propositional unity

In a fresh task, use:

> 用 OAS 做一张生命主题视觉作品，主体与表现方式自行判断，表达变化与统一。

Assess whether the chosen proposition benefits from one form, several states of one identity, or heterogeneous forms. For every major form, identify its distinct contribution and the relationship that makes it belong. Do not require several stages in every candidate. When several are chosen, compare their differences after removing decorative texture and nonessential geometry.

Use the growth anchor as positive raw evidence: the hand, seed, shoots, roots, canopy, and tree-ring material can express receiving, potential, manifestation, support, expansion, and memory while a route and material relationships unify them. Do not claim they depict one botanical specimen. Do not require the same objects, layout, colors, or lifecycle in new work. Progression, branching, recurrence, opposition, coexistence, and rupture remain alternatives.

Include a paired control with a non-growth proposition, such as “归属” or “等待”, to detect compulsory lifecycle staging. Accept when identity continuity or propositional continuity is visually meaningful, and reject filters on interchangeable copies or arbitrary symbols justified only in prose. Post-revision generation is unrun.

### T. Human detail, first emotion, and preserved age

In a fresh task, use:

> 用 OAS 表现两代人之间温柔而庄重的触碰，保留年长者的年龄特征，不加文字。

The intended relation and emotional impression lead at thumbnail size. At full size, inspect viewpoint, hand scale, finger flexion, dark joints, crease density, nails, skin patterns, local volume, and edge finish. Anatomical credibility and visible age remain, but every pore and wrinkle need not be resolved. Dense hatching must not create unintended clinical, threatening, or grotesque body emphasis. A pressure print or other carrier must not repeat the same high-frequency skin stimulation at larger scale.

Reject a remedy that simply blurs the whole image, smooths away age, makes every figure youthful, or strips mixed material and geometry. Re-draw and redistribute attention so gesture, contact, and essential structure lead over redundant surface texture.

Paired control:

> 用 OAS 做一幅表现风霜岁月的老年手部版画，保留粗粝质感和年龄痕迹。

This control permits purposeful coarseness. The rule must distinguish the intended register rather than universally beautifying, smoothing, or banning close-ups and older bodies.

Observed before revision: a life-theme candidate combined a weathered elderly hand, dense engraved old skin, large hand scale, and enlarged pressure-print ridges. The actual hand's skin, creases, joints, and tactile modeling dominated the tender contact; the run viewed thumbnail, grayscale, and a detail crop but still accepted it. This demonstrates a depiction and acceptance failure, not merely a missing preview. Post-revision generation is unrun.

### U. Classical philosophy and sacredness without a motif checklist

In a fresh task, use:

> 用 OAS 制作一张“有限与无限”的艺术视觉作品，带有古希腊与中欧的美感与哲学，略有神圣感，题材自行判断。

Evaluate proportion, relation between parts and whole, intervals, rhythm, gesture, scale, silence, authored marks, and material time. Sacredness should be perceptible as a register without mandatory columns, gods, crosses, halos, altars, gold, or a religious scene. Do not average all traditions into one generic style or impose grimness and coarse bodily detail.

Use a paired explicit style or mood request to verify that the default yields to the user's direction. An appropriate motif remains valid when it contributes to the actual proposition. This is a planned regression; no post-revision image is claimed.

### V. Text-free default and requested-copy override

In fresh tasks, use each short request without extra text instructions:

> 用 OAS 设计一张，主体是知识。

> 用 OAS 做一张生命主题视觉作品，文字是否加入自行判断。

Accept only if candidates and final artwork contain no automatic titles, translations, subtitles, slogans, footers, labels, numbers, indices, signatures, watermarks, or pseudo-writing. Compose the whole field as artwork; do not reserve a top title band, bottom footer strip, empty text box, or fixed typography percentage. Do not spend a default text-free task selecting fonts or producing a typography-only SVG.

Inspect books, maps, scanned material, and study sheets for accidental or inherited text. Non-lettered imagery and geometry remain permitted. A theme name is the subject, not an instruction to print it. Delegating the text decision retains the user's default rather than triggering a new clarification question.

Paired override control:

> 用 OAS 做一张知识主题海报，请加入准确标题“知识”，不加其他文字。

The override includes only the requested title, implemented accurately and editably after accepting the text-free primary visual. It does not add an English translation, slogan, subtitle, or footer. Functional frontend text is covered separately by Case 3 and must not be removed by the artwork policy.

This is a planned policy regression. Rule, YAML, link, and package checks do not demonstrate a generated image is free of text; mark forward generation unrun until actual outputs are opened.
